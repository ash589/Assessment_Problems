package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController; 

@RestController
public class Calculator {
	
	@GetMapping("addition")
    public double getAdd(@RequestParam(defaultValue = "0") Integer i, @RequestParam(defaultValue = "0") Integer j){
        double result = i + j;
        return result;
    }
    @GetMapping("subtraction")
    public double getSubtract(@RequestParam(defaultValue = "0") Integer i, @RequestParam(defaultValue = "0") Integer j){
        double result = i - j;
        return result;
    }
    @GetMapping("multiplication")
    public double GetMultiply(@RequestParam(defaultValue = "0") Integer i, @RequestParam(defaultValue = "0") Integer j){
        double result = i * j;
        return result;
    }
    @GetMapping("division")
    public double getDivide(@RequestParam(defaultValue = "0") Double i, @RequestParam(defaultValue = "1") Double j){
        double result = i / j;
        return result;
    }
    @GetMapping("power")
    public double getPower(@RequestParam(defaultValue = "0") Double i, @RequestParam(defaultValue = "1") Double j){
        double result = Math.pow(i,j);
        return result;
    }
    @GetMapping("squareroot")
    public double getPower(@RequestParam(defaultValue = "0") Double i){
        double result = Math.sqrt(i);
        return result;
    }

    @GetMapping("sayHello")
    public String sayHello(){
        return "Hello Spring!";
    }

}
